#!/bin/bash

java -cp out connectx.CXPlayerTester $@
