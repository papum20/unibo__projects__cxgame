#!/bin/bash

rm -rf out
