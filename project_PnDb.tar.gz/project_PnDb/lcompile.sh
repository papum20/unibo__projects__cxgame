#!/bin/bash

javac -d out -sourcepath src	\
	src/connectx/pndb/*.java src/connectx/pndb/*/*.java

