#!/bin/bash

java -cp out connectx.CXGame $@
