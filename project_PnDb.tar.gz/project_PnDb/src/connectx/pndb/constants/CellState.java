package connectx.pndb.constants;



public final class CellState {

	public static final byte FREE	= 0;
	public static final byte P1		= 1;
	public static final byte P2		= 2;

	public static final byte NULL	= -1;

}
